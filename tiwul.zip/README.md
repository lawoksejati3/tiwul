# Upgrade-THRIFT---0.11.0
Masukan Folder² Thrift Ini Ke Folder Bot Yang Kalian Pilih Agar Bisa Digunakan

THRIFT BY : BANG ACIL PRANKBOTS

from thrift.unverting import *

from thrift.TMultiplexedProcessor import *

from thrift.TSerialization import *

from thrift.TRecursive import *

from thrift import transport, protocol, server

Copas Ajah ke 5 from thrift di atas ke script bot kalian, dan pindahkan folder thrift & ecc nya ke folder bot kalian

untuk memaksimalkan kinerja bot kalian
